import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, reducedMotion: "reduce" });
const p = await ctx.newPage();
const probe = async (id, labelSel, lineSel) => {
  await p.goto(`http://127.0.0.1:5278/?print=family&id=${id}&theme=dark`);
  await p.waitForTimeout(600);
  return await p.evaluate(([ls, ln]) => {
    const labels = [...document.querySelectorAll(ls)];
    const lines = [...document.querySelectorAll(ln)];
    const out = [];
    for (let i = 0; i < Math.min(labels.length, lines.length); i++) {
      const lb = labels[i].getBoundingClientRect();
      const lnEl = lines[i].getBoundingClientRect();
      out.push({
        label: labels[i].textContent.trim(),
        labelCenterY: +(lb.top + lb.height / 2).toFixed(1),
        lineY: +(lnEl.top + lnEl.height / 2).toFixed(1),
        delta: +((lb.top + lb.height / 2) - (lnEl.top + lnEl.height / 2)).toFixed(1),
      });
    }
    return out;
  }, [labelSel, lineSel]);
};
const week = await probe("calendar", ".week-cal__hour", ".week-cal__daycol .week-cal__line");
const day = await probe("calendar", ".day-cal__hour", ".day-cal__track .day-cal__line:not(.day-cal__line--faint)");
console.log("WEEK (first 6):", JSON.stringify(week.slice(0, 6)));
console.log("DAY  (first 6):", JSON.stringify(day.slice(0, 6)));
await b.close();

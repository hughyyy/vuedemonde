#!/usr/bin/env python3
"""Summarize degradation-probe jsonl logs: flag transitions, first anomalies,
header/worker stability, and cross-mode comparison."""

from __future__ import annotations

import argparse
import json
import sys


def load(path: str) -> list[dict]:
    rows = []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def summarize(path: str) -> None:
    rows = load(path)
    if not rows:
        print(f"{path}: empty")
        return
    print(f"== {path}  calls={len(rows)}")
    hdr_keys = ("server", "x-request-id", "x-amzn-requestid", "x-hf-request-id", "cf-ray", "x-served-by", "x-ratelimit-remaining")
    seen: dict[str, set] = {}
    prev_flags: tuple = tuple()
    transitions = 0
    first_flagged = None
    for r in rows:
        flags = tuple(r["flags"])
        if flags != prev_flags and prev_flags:
            transitions += 1
            print(f"  transition at idx={r['idx']}: {prev_flags} -> {flags}  ({r['image']})")
        prev_flags = flags
        if flags != ("normal",) and first_flagged is None:
            first_flagged = r
        for k in hdr_keys:
            v = r.get("headers", {}).get(k)
            if v is not None:
                seen.setdefault(k, set()).add(v)
    ok = sum(1 for r in rows if r.get("ok"))
    flagged = sum(1 for r in rows if r["flags"] != ["normal"])
    errs = sum(1 for r in rows if not r.get("ok"))
    print(f"  ok={ok} errored={errs} flagged={flagged} transitions={transitions}")
    latency = [r.get("latency_s") or 0 for r in rows]
    print(f"  latency min/median/max = {min(latency):.1f}/{sorted(latency)[len(latency)//2]:.1f}/{max(latency):.1f}s")
    for k, vals in seen.items():
        shown = ", ".join(sorted(vals)[:4])
        more = f" (+{len(vals)-4} more)" if len(vals) > 4 else ""
        print(f"  header {k}: {len(vals)} distinct [{shown}{more}]")
    reasons = {}
    for r in rows:
        reasons[r.get("finish_reason")] = reasons.get(r.get("finish_reason"), 0) + 1
    print(f"  finish_reasons: {reasons}")
    if first_flagged is not None:
        print(f"  FIRST NON-NORMAL idx={first_flagged['idx']} image={first_flagged['image']} latency={first_flagged.get('latency_s')}s")
        print(f"    flags={first_flagged['flags']} finish={first_flagged.get('finish_reason')}")
        print(f"    http={first_flagged.get('http_version')} headers={first_flagged.get('headers')}")
        content = first_flagged.get("content") or first_flagged.get("error") or ""
        print(f"    content: {content[:400]!r}")


def compare(a: str, b: str) -> None:
    ra, rb = load(a), load(b)
    def stats(rows):
        flagged = sum(1 for r in rows if r["flags"] != ["normal"])
        errs = sum(1 for r in rows if not r.get("ok"))
        return flagged, errs
    fa, ea = stats(ra)
    fb, eb = stats(rb)
    last = lambda rows: (rows[-1]["flags"], rows[-1].get("finish_reason"), rows[-1].get("content") or rows[-1].get("error") or "")
    print(f"COMPARE:\n  {a}: {len(ra)} calls, flagged={fa}, errored={ea}, last={last(ra)}\n  {b}: {len(rb)} calls, flagged={fb}, errored={eb}, last={last(rb)}")
    for r in rb:
        if r["flags"] != ["normal"]:
            print(f"  {b} flagged idx={r['idx']}: {r['flags']} | {(r.get('content') or r.get('error') or '')[:200]!r}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("logs", nargs="+")
    ap.add_argument("--compare", action="store_true")
    a = ap.parse_args()
    if a.compare and len(a.logs) == 2:
        summarize(a.logs[0])
        summarize(a.logs[1])
        compare(a.logs[0], a.logs[1])
    else:
        for p in a.logs:
            summarize(p)
    return 0


if __name__ == "__main__":
    sys.exit(main())

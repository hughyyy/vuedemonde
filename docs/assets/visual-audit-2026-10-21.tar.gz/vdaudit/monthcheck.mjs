import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, reducedMotion: "reduce" });
const p = await ctx.newPage();
await p.goto("http://127.0.0.1:5278/?print=family&id=calendar&theme=dark");
await p.waitForTimeout(700);
const r = await p.evaluate(() => {
  const month = document.querySelector(".month-cal");
  const card = month?.closest(".demo");
  if (!month || !card) return { none: true };
  const mr = month.getBoundingClientRect();
  const cr = card.getBoundingClientRect();
  const days = [...month.querySelectorAll(".month-cal__day")].map((d) => {
    const r2 = d.getBoundingClientRect();
    return { x: Math.round(r2.x), right: Math.round(r2.right), w: Math.round(r2.width) };
  });
  const chips = [...month.querySelectorAll(".event-chip[title]")];
  const noTitle = chips.length;
  const ellipsized = chips.filter((c) => c.querySelector(".event-chip__title")?.scrollWidth > c.querySelector(".event-chip__title")?.clientWidth + 1).length;
  return {
    cardW: Math.round(cr.width),
    monthW: Math.round(mr.width),
    monthFitsCard: mr.right <= cr.right + 1,
    lastDayRight: days.length ? days[days.length - 1].right : null,
    firstDayRight: days.length ? days[0].right : null,
    saturdayVisible: days.length ? days[6].right <= cr.right + 1 : false,
    chipsWithTitle: noTitle,
    chipsEllipsized: ellipsized,
  };
});
console.log(JSON.stringify(r, null, 1));
await b.close();

import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
import { mkdirSync, writeFileSync } from "node:fs";

const OUT = "/tmp/vdaudit";
mkdirSync(OUT, { recursive: true });
const BASE = "http://127.0.0.1:5278";
const FAMILIES = ["primitives","inputs","overlays","navigation","data","layout","charts","calendar","board"];

const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, deviceScaleFactor: 2, reducedMotion: "reduce" });
const page = await ctx.newPage();
const manifest = [];

for (const family of FAMILIES) {
  await page.goto(`${BASE}/?print=family&id=${family}&theme=dark`);
  await page.waitForSelector("#print-section");
  await page.evaluate(() => document.fonts?.ready);
  await page.waitForTimeout(600); // print-mode panel opens are async (fonts + nextTick)
  const cards = await page.$$eval("#print-section .demo", (els) =>
    els.map((e) => {
      const r = e.getBoundingClientRect();
      return { t: (e.querySelector("[class*=title]")?.textContent || "card").trim() };
    }),
  );
  let i = 0;
  for (const card of await page.locator("#print-section .demo").all()) {
    const slug = `${family}-${String(i).padStart(2, "0")}-${cards[i].t.replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase().slice(0, 40)}`;
    await card.screenshot({ path: `${OUT}/${slug}.png` });
    manifest.push({ file: `${slug}.png`, family, title: cards[i].t });
    i++;
  }
  // teleported overlay panels for the overlays family
  if (family === "overlays") {
    for (const [sel, name] of [
      [".app-dialog", "dialog"],
      [".drawer", "drawer"],
      [".popover__panel", "popover"],
      [".confirm-popup__panel", "confirm-popup"],
      [".context-menu__panel", "context-menu"],
      [".cmd-menu", "command-menu"],
      [".toast-host", "toast-host"],
    ]) {
      const loc = page.locator(sel);
      if (await loc.count()) {
        const f = `overlays-tele-${name}.png`;
        await loc.first().screenshot({ path: `${OUT}/${f}` });
        manifest.push({ file: f, family: "overlays", title: `teleported: ${name}` });
      }
    }
  }
  console.log(`captured ${family}: ${i} cards`);
}
writeFileSync(`${OUT}/manifest.json`, JSON.stringify(manifest, null, 1));
console.log(`total ${manifest.length} images`);
await b.close();

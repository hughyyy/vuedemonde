import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, reducedMotion: "reduce" });
const p = await ctx.newPage();
const FAMILIES = ["primitives", "inputs", "navigation", "data", "layout"];
const results = [];
for (const family of FAMILIES) {
  await p.goto(`http://127.0.0.1:5278/?print=family&id=${family}&theme=dark`);
  await p.waitForTimeout(600);
  const cards = await p.evaluate(() =>
    [...document.querySelectorAll("#print-section .demo")].map((e, i) => ({
      i,
      t: (e.querySelector("[class*=title]")?.textContent || "").trim().slice(0, 30),
    })),
  );
  for (const c of cards) {
    const ok = await p.evaluate((idx) => {
      const card = document.querySelectorAll("#print-section .demo")[idx];
      const f = [...card.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')]
        .find((el) => !el.disabled && el.offsetParent !== null);
      if (!f) return null;
      window.__focusTarget = f;
      return `${f.tagName}.${(f.className || "").toString().split(" ")[0]}`;
    }, c.i);
    if (!ok) {
      results.push({ family, card: c.t, focusable: "none" });
      continue;
    }
    let ring = null;
    for (let t = 0; t < 60; t++) {
      await p.keyboard.press("Tab");
      ring = await p.evaluate(() => {
        if (document.activeElement !== window.__focusTarget) return null;
        const cs = getComputedStyle(document.activeElement);
        return { el: `${document.activeElement.tagName}.${(document.activeElement.className || "").toString().split(" ")[0]}`, outline: cs.outline, width: parseFloat(cs.outlineWidth) || 0 };
      });
      if (ring) break;
    }
    results.push({ family, card: c.t, focusable: ok, ring: ring ? `${ring.outline} (w=${ring.width}px)` : "NOT-REACHED" });
    await p.evaluate(() => document.activeElement?.blur?.());
  }
}
const withRing = results.filter((r) => r.ring && r.ring !== "NOT-REACHED" && !r.ring.includes("w=0px"));
const noRing = results.filter((r) => r.ring && (r.ring.includes("w=0px") || r.ring === "NOT-REACHED"));
console.log(`cards=${results.length} | ring-visible=${withRing.length} | zero-or-unreached=${noRing.length} | no-focusable=${results.filter((r) => r.focusable === "none").length}`);
for (const r of noRing) console.log("NO-RING:", JSON.stringify(r));
await b.close();

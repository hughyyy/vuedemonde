import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
import { mkdirSync, writeFileSync } from "node:fs";

const OUT = "/tmp/vdaudit";
mkdirSync(OUT, { recursive: true });
const BASE = "http://127.0.0.1:5278";
const FOCUS_FAMILIES = ["primitives", "inputs", "navigation", "data", "layout"];
const FAMILIES = ["primitives","inputs","overlays","navigation","data","layout","charts","calendar","board"];

const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, deviceScaleFactor: 2, reducedMotion: "reduce" });
const page = await ctx.newPage();
const manifest = [];

for (const family of FAMILIES) {
  await page.goto(`${BASE}/?print=family&id=${family}&theme=dark`);
  await page.waitForSelector("#print-section");
  await page.evaluate(() => document.fonts?.ready);
  await page.waitForTimeout(600);
  const cards = await page.$$eval("#print-section .demo", (els) =>
    els.map((e) => (e.querySelector("[class*=title]")?.textContent || "card").trim()),
  );
  const locs = await page.locator("#print-section .demo").all();
  for (let i = 0; i < locs.length; i++) {
    const slug = `${family}-${String(i).padStart(2, "0")}-${cards[i].replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase().slice(0, 40)}`;
    await locs[i].screenshot({ path: `${OUT}/${slug}.png` });
    manifest.push({ file: `${slug}.png`, family, title: cards[i], state: "static" });
    if (FOCUS_FAMILIES.includes(family)) {
      // focus the card's first focusable via REAL Tab presses (so :focus-visible paints)
      await locs[i].scrollIntoViewIfNeeded();
      const ok = await page.evaluate((idx) => {
        const card = document.querySelectorAll("#print-section .demo")[idx];
        if (!card) return false;
        const f = [...card.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')]
          .find((el) => !el.disabled && el.offsetParent !== null);
        if (!f) return false;
        window.__focusTarget = f;
        return true;
      }, i);
      if (ok) {
        for (let t = 0; t < 60; t++) {
          await page.keyboard.press("Tab");
          const hit = await page.evaluate(() => document.activeElement === window.__focusTarget);
          if (hit) break;
        }
        await locs[i].screenshot({ path: `${OUT}/${slug}-focused.png` });
        manifest.push({ file: `${slug}-focused.png`, family, title: cards[i], state: "focused" });
        await page.evaluate(() => (document.activeElement?.blur?.()));
      }
    }
  }
  if (family === "overlays") {
    for (const [sel, name] of [
      [".app-dialog", "dialog"],
      [".drawer", "drawer"],
      [".popover__panel", "popover"],
      [".confirm-popup__panel", "confirm-popup"],
      [".context-menu__panel", "context-menu"],
      [".toast-host", "toast-host"],
    ]) {
      const loc = page.locator(sel);
      if (await loc.count()) {
        const f = `overlays-tele-${name}.png`;
        await loc.first().screenshot({ path: `${OUT}/${f}` });
        manifest.push({ file: f, family: "overlays", title: `teleported: ${name}`, state: "static" });
      }
    }
  }
  console.log(`captured ${family}: ${cards.length} cards`);
}
writeFileSync(`${OUT}/manifest2.json`, JSON.stringify(manifest, null, 1));
console.log(`total ${manifest.length} images`);
await b.close();

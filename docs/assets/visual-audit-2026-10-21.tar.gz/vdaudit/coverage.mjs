import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1400 }, reducedMotion: "reduce" });
const p = await ctx.newPage();
await p.goto("http://127.0.0.1:5278/?print=family&id=overlays&theme=dark");
await p.waitForTimeout(700);
const r = await p.evaluate(() => {
  const out = [];
  for (const c of document.querySelectorAll("#print-section .demo")) {
    const rect = c.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + 30; // near the card's top title area
    const el = document.elementFromPoint(cx, cy);
    const own = c.contains(el) || (el && c === el);
    const coveredBy = !own ? (el ? (el.className || el.tagName) + " :: " + (el.textContent || "").slice(0, 24) : "null") : "-";
    out.push({ t: (c.querySelector("[class*=title]")?.textContent || "").trim().slice(0, 26), own, coveredBy });
  }
  return out;
});
console.log(JSON.stringify(r, null, 1));
await b.close();

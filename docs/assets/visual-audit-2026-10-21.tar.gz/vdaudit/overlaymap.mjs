import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, reducedMotion: "reduce" });
const p = await ctx.newPage();
await p.goto("http://127.0.0.1:5278/?print=family&id=overlays&theme=dark");
await p.waitForTimeout(700);
const r = await p.evaluate(() => {
  const cards = [...document.querySelectorAll("#print-section .demo")].map((c) => {
    const r2 = c.getBoundingClientRect();
    return { t: (c.querySelector("[class*=title]")?.textContent || "").trim().slice(0, 26), y: Math.round(r2.y), h: Math.round(r2.height), x: Math.round(r2.x), w: Math.round(r2.width) };
  });
  const panels = {};
  for (const [name, sel] of [["dialog", ".app-dialog"], ["scrim", ".app-dialog__scrim"], ["popover", ".popover__panel"], ["confirm", ".confirm-popup__panel"], ["ctx", ".context-menu__panel"], ["drawer", ".drawer__panel"], ["toasts", ".toast-host"]]) {
    const el = document.querySelector(sel);
    if (el) { const r2 = el.getBoundingClientRect(); panels[name] = { y: Math.round(r2.y), h: Math.round(r2.height), x: Math.round(r2.x), w: Math.round(r2.width) }; }
  }
  return { cards, panels, pageH: document.body.scrollHeight };
});
console.log(JSON.stringify(r, null, 1));
await b.close();

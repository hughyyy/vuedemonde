import { chromium } from "/mnt/shared/Source/vuedemond/node_modules/playwright/index.mjs";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1000, height: 1100 }, reducedMotion: "reduce" });
const p = await ctx.newPage();
await p.goto("http://127.0.0.1:5278/?print=family&id=overlays&theme=dark");
await p.waitForTimeout(700);
const r = await p.evaluate(() => {
  const rect = (el) => { const r2 = el.getBoundingClientRect(); return { x: r2.x, y: r2.y, w: r2.width, h: r2.height }; };
  const overlap = (a, b) => !(a.x + a.w <= b.x || b.x + b.w <= a.x || a.y + a.h <= b.y || b.y + b.h <= a.y);
  const boxes = {
    dialogBox: rect(document.querySelector(".app-dialog")),
    drawerPanel: rect(document.querySelector(".drawer__panel")),
    popover: rect(document.querySelector(".popover__panel")),
    confirm: rect(document.querySelector(".confirm-popup__panel")),
    ctx: rect(document.querySelector(".context-menu__panel")),
    toasts: rect(document.querySelector(".toast-host")),
  };
  const cards = [...document.querySelectorAll("#print-section .demo")].map((c) => {
    const t = (c.querySelector("[class*=title]")?.textContent || "").trim().slice(0, 26);
    const cr = rect(c);
    const hits = Object.entries(boxes).filter(([, br]) => overlap(cr, br)).map(([n]) => n);
    return { t, coveredBy: hits };
  });
  return { cards, boxes: Object.fromEntries(Object.entries(boxes).map(([k, v]) => [k, `${v.y}-${v.y + v.h} x${v.x}-${v.x + v.w}`])) };
});
console.log(JSON.stringify(r, null, 1));
await b.close();

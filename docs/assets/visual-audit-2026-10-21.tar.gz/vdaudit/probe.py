#!/usr/bin/env python3
"""Degradation probe: long-lived vs fresh-connection HF inference calls.

Simulates the hf-vision-mcp server's client path (same InferenceClient /
shared httpx session) while capturing the raw HTTP layer per call:
status, response headers, http_version, finish_reason, usage.

Modes:
  reuse  — one InferenceClient for the whole run (server behavior today)
  fresh  — close_session() + new InferenceClient before every call

Requires HF_TOKEN in the environment.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

import huggingface_hub.inference._client as _ic
import huggingface_hub.utils._http as _http
from huggingface_hub import InferenceClient

from hf_vision_mcp.config import load_config
from hf_vision_mcp.images import ImageInputError, to_data_uri
from hf_vision_mcp.prompts import ASK_DEFAULT, DESCRIBE_DEFAULT, SCREENSHOT_DEFAULT, build_messages

PROBE: dict = {"headers": None, "http_version": None}

_orig_get_session = _http.get_session


def _wrapped_get_session():
    client = _orig_get_session()
    if not getattr(client, "_probe_wrapped", False):
        orig_stream = client.stream

        def stream(*args, **kwargs):
            cm = orig_stream(*args, **kwargs)

            class _CM:
                def __enter__(self):
                    self.resp = cm.__enter__()
                    PROBE["headers"] = dict(self.resp.headers)
                    PROBE["http_version"] = getattr(self.resp, "http_version", None)
                    return self.resp

                def __exit__(self, *exc):
                    return cm.__exit__(*exc)

            return _CM()

        client.stream = stream
        client._probe_wrapped = True
    return client


_http.get_session = _wrapped_get_session
_ic.get_session = _wrapped_get_session  # _client.py holds a module-global reference

# --- degradation classifiers -------------------------------------------------

REFUSAL_PATTERNS = [
    "text-based AI",
    "do not have the capability",
    "cannot fulfill",
    "unable to",
    "as an AI",
    "i cannot",
    "i don't have the ability",
    "largely obscured or clipped",
    "cannot generate, render, or export",
]
GEN_PAYLOAD_PATTERNS = ["dalle", "text2im", '"model": "dall', "generate an image", "generate, render, or export"]
JSON_MARKER_RE = re.compile(r'"point"\s*:|"label"\s*:|"x"\s*:\s*["\d-]|"y"\s*:\s*["\d-]')
TEMPLATE_TIPS = {
    "A": SCREENSHOT_DEFAULT,
    "B": "Describe only what is visible in this screenshot. Be precise; report UI elements, text, and values.",
    "C": "What application or screen is shown here? List the visible UI elements and their state.",
}


def classify(content: str) -> list[str]:
    low = content.lower()
    flags = []
    if any(p in low for p in REFUSAL_PATTERNS):
        flags.append("refusal")
    if any(p in low for p in GEN_PAYLOAD_PATTERNS):
        flags.append("gen_payload")
    if JSON_MARKER_RE.search(content) or content.lstrip().startswith(("{", "[")):
        flags.append("json_markers")
    if len(content.strip()) < 60:
        flags.append("terse")
    if not flags:
        flags.append("normal")
    return flags


def pick_image(paths: list[str], i: int) -> str:
    return paths[i % len(paths)]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["reuse", "fresh"], required=True)
    ap.add_argument("--count", type=int, default=30)
    ap.add_argument("--tpl", choices=["A", "B", "C", "all"], default="all", help="fixed prompt template (A=server default) or all=cycle")
    ap.add_argument("--images-dir", default="/tmp/vdaudit")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    if not os.environ.get("HF_TOKEN"):
        print("error: HF_TOKEN is not set", file=sys.stderr)
        return 2

    paths = sorted(
        p for p in os.listdir(args.images_dir) if p.endswith(".png") and not p.startswith(".")
    )
    if not paths:
        print(f"error: no pngs in {args.images_dir}", file=sys.stderr)
        return 2

    cfg = load_config()
    print(f"mode={args.mode} count={args.count} model={cfg.target} images={len(paths)}", file=sys.stderr)

    client: InferenceClient | None = None
    if args.mode == "reuse":
        client = InferenceClient(model=cfg.target, token=os.environ.get("HF_TOKEN"), timeout=cfg.timeout)
    rows = []
    for i in range(args.count):
        if args.mode == "fresh":
            _http.close_session()
            client = InferenceClient(model=cfg.target, token=os.environ.get("HF_TOKEN"), timeout=cfg.timeout)

        image_name = pick_image(paths, i)
        try:
            uri = to_data_uri(os.path.join(args.images_dir, image_name))
        except ImageInputError as exc:
            print(f"[{i}] image error: {exc}", file=sys.stderr)
            continue
        tpl = TEMPLATE_TIPS["A"] if i % 4 else TEMPLATE_TIPS["B"]
        if i % 5 == 0:
            tpl = TEMPLATE_TIPS["C"]
        if args.tpl != "all":
            tpl = TEMPLATE_TIPS[args.tpl]
        default = SCREENSHOT_DEFAULT if tpl == TEMPLATE_TIPS["A"] else DESCRIBE_DEFAULT
        msgs = build_messages(uri, tpl, default)

        row = {
            "idx": i,
            "mode": args.mode,
            "image": image_name,
            "prompt_tpl": "A" if tpl == TEMPLATE_TIPS["A"] else ("B" if tpl == TEMPLATE_TIPS["B"] else "C"),
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": False,
        }
        PROBE["headers"] = None
        t0 = time.monotonic()
        try:
            resp = client.chat_completion(messages=msgs, model=cfg.target, max_tokens=cfg.max_tokens)
            row["latency_s"] = round(time.monotonic() - t0, 2)
            row["ok"] = True
            row["http_version"] = PROBE["http_version"]
            # keep interesting headers only
            hdrs = PROBE["headers"] or {}
            row["headers"] = {
                k: v for k, v in hdrs.items()
                if k.lower() in {"server", "x-request-id", "x-amzn-requestid", "cf-ray", "content-type", "x-hf-request-id", "x-served-by", "x-ratelimit-remaining", "x-ratelimit-limit", "x-ratelimit-reset", "retry-after"}
            }
            row["model"] = resp.model
            row["finish_reason"] = resp.choices[0].finish_reason
            row["usage"] = resp.usage.__dict__ if resp.usage else None
            row["content"] = resp.choices[0].message.content or ""
        except Exception as exc:  # noqa: BLE001
            row["latency_s"] = round(time.monotonic() - t0, 2)
            row["error"] = f"{exc.__class__.__name__}: {exc}"

        row["flags"] = classify(row.get("content") or row.get("error") or "")
        rows.append(row)
        with open(args.out, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(row) + "\n")

        summary = row.get("content") or row.get("error") or ""
        print(
            f"[{i:02d}] {row['image'][:34]:34s} {row.get('latency_s','?'):>7}s "
            f"{','.join(row['flags']):>14s} | {summary[:110]!r}",
            file=sys.stderr,
        )

    ok = sum(1 for r in rows if r["ok"])
    flagged = sum(1 for r in rows if r["flags"] != ["normal"])
    print(f"DONE mode={args.mode} calls={len(rows)} ok={ok} flagged={flagged}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
